/*
# Crear tabla de pedidos (single-tenant, no auth)

1. Tabla nueva
- `pedidos`: guarda cada pedido confirmado desde la web.
  - `id` (uuid, primary key)
  - `cliente_nombre` (text, nombre de quien pide)
  - `cliente_telefono` (text, contacto)
  - `items` (jsonb, lista de productos con nombre, precio y cantidad)
  - `total` (integer, total del pedido en pesos chilenos)
  - `estado` (text, estado del pedido: pendiente/preparando/listo/entregado)
  - `created_at` (timestamptz, fecha de creación)

2. Seguridad
- RLS habilitado en `pedidos`.
- Políticas para anon + authenticated: la app no tiene login, así que
  anon puede crear y leer pedidos. Los pedidos son datos compartidos
  del local (no hay aislamiento por usuario).
*/

CREATE TABLE IF NOT EXISTS pedidos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_nombre text NOT NULL,
  cliente_telefono text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  total integer NOT NULL DEFAULT 0,
  estado text NOT NULL DEFAULT 'pendiente',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_pedidos" ON pedidos;
CREATE POLICY "anon_select_pedidos" ON pedidos FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_pedidos" ON pedidos;
CREATE POLICY "anon_insert_pedidos" ON pedidos FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_pedidos" ON pedidos;
CREATE POLICY "anon_update_pedidos" ON pedidos FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_pedidos" ON pedidos;
CREATE POLICY "anon_delete_pedidos" ON pedidos FOR DELETE
  TO anon, authenticated USING (true);
