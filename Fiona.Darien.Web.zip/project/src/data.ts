export type Categoria = 'italianos' | 'dinamicos' | 'americanos' | 'combos';

export interface Promo {
  nombre: string;
  desc: string;
  precio: number;
  antes: number | null;
  img: string;
}

export const PROMOS: Record<Categoria, Promo[]> = {
  italianos: [
    {
      nombre: 'Completo Italiano',
      desc: 'Tomate, palta y mayonesa. El clásico que nunca falla.',
      precio: 2500,
      antes: null,
      img: 'https://images.pexels.com/photos/4113504/pexels-photo-4113504.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
    {
      nombre: 'Italiano Doble',
      desc: 'Dos vienesas, doble palta y doble mayonesa.',
      precio: 3200,
      antes: 3800,
      img: 'https://images.pexels.com/photos/4113503/pexels-photo-4113503.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
  ],
  dinamicos: [
    {
      nombre: 'Completo Dinámico',
      desc: 'Tomate, palta, chucrut y salsa americana.',
      precio: 2600,
      antes: null,
      img: 'https://images.pexels.com/photos/4113500/pexels-photo-4113500.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
    {
      nombre: 'Dinámico XL',
      desc: 'Versión grande con doble de todos los aderezos.',
      precio: 3400,
      antes: 3900,
      img: 'https://images.pexels.com/photos/4113499/pexels-photo-4113499.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
  ],
  americanos: [
    {
      nombre: 'Hot Dog Americano',
      desc: 'Mostaza, ketchup y cebolla picada.',
      precio: 2800,
      antes: null,
      img: 'https://images.pexels.com/photos/4113501/pexels-photo-4113501.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
    {
      nombre: 'Americano Queso',
      desc: 'Con salsa de queso cheddar derretido.',
      precio: 3100,
      antes: null,
      img: 'https://images.pexels.com/photos/6441795/pexels-photo-6441795.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
  ],
  combos: [
    {
      nombre: "Combo Doggy's",
      desc: 'Un hot dog a elección, papas y bebida.',
      precio: 4200,
      antes: 4900,
      img: 'https://images.pexels.com/photos/8287715/pexels-photo-8287715.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
    {
      nombre: 'Combo Doble',
      desc: 'Dos hot dogs, papas grandes y dos bebidas.',
      precio: 6900,
      antes: 7900,
      img: 'https://images.pexels.com/photos/4113458/pexels-photo-4113458.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
    },
  ],
};

export interface MenuItem {
  nombre: string;
  tipo: string;
  precio: number;
  img: string;
}

export const MENU: MenuItem[] = [
  { nombre: 'Completo Italiano', tipo: 'completo', precio: 2500, img: 'https://images.pexels.com/photos/4113504/pexels-photo-4113504.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
  { nombre: 'Completo Dinámico', tipo: 'completo', precio: 2600, img: 'https://images.pexels.com/photos/4113500/pexels-photo-4113500.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
  { nombre: 'Hot Dog Americano', tipo: 'americano', precio: 2800, img: 'https://images.pexels.com/photos/4113501/pexels-photo-4113501.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
  { nombre: 'Americano Queso', tipo: 'americano', precio: 3100, img: 'https://images.pexels.com/photos/6441795/pexels-photo-6441795.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
  { nombre: 'Italiano Doble', tipo: 'completo', precio: 3200, img: 'https://images.pexels.com/photos/4113503/pexels-photo-4113503.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
  { nombre: 'Dinámico XL', tipo: 'completo', precio: 3400, img: 'https://images.pexels.com/photos/4113499/pexels-photo-4113499.jpeg?auto=compress&cs=tinysrgb&h=200&w=200' },
];

export const CATEGORIAS: { id: Categoria; label: string }[] = [
  { id: 'italianos', label: 'Italianos' },
  { id: 'dinamicos', label: 'Dinámicos' },
  { id: 'americanos', label: 'Americanos' },
  { id: 'combos', label: 'Combos' },
];

export function formatoCLP(n: number): string {
  return '$' + n.toLocaleString('es-CL');
}
