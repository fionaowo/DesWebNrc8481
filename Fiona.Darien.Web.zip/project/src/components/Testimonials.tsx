import { Star, Quote } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

const REVIEWS = [
  {
    nombre: 'Camila Rojas',
    rol: 'Clienta frecuente',
    texto: 'El completo italiano de Doggy\u2019s es el mejor que he probado. La palta siempre fresca y el pan suavecito. Vuelvo cada semana.',
    avatar: 'C',
  },
  {
    nombre: 'Felipe Muñoz',
    rol: 'Reseña en Google',
    texto: 'Pedí el combo doble para compartir con mi polola y nos alcanzó de sobra. Abundante, rico y a buen precio. Recomendadísimo.',
    avatar: 'F',
  },
  {
    nombre: 'Daniela Pérez',
    rol: 'Foodie',
    texto: 'La salsa secreta es adictiva. No sé qué le ponen pero no puedo dejar de pedirlo. Atención rápida y amable siempre.',
    avatar: 'D',
  },
];

export default function Testimonials() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section className="py-20 sm:py-28 bg-marron-fondo3">
      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className={`text-center mb-12 ${visible ? 'animate-fade-up' : 'opacity-0'}`}>
          <div className="flex items-center justify-center gap-1 mb-3">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-mostaza-clara text-mostaza-clara" />
            ))}
          </div>
          <h2 className="font-display text-4xl sm:text-5xl text-crema">
            Lo que dicen nuestros<br />
            <span className="text-mostaza-clara">clientes</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {REVIEWS.map((r, i) => (
            <article
              key={r.nombre}
              className={`relative p-7 rounded-3xl bg-crema-carta/5 border border-crema/10 hover:border-mostaza/30 transition-all hover:bg-crema-carta/10 ${
                visible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <Quote className="w-8 h-8 text-mostaza/30 mb-4" />
              <p className="text-crema/80 leading-relaxed mb-6">{r.texto}</p>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-mostaza text-cafe font-display text-lg flex items-center justify-center">
                  {r.avatar}
                </div>
                <div>
                  <p className="font-semibold text-crema text-sm">{r.nombre}</p>
                  <p className="text-crema/40 text-xs">{r.rol}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
