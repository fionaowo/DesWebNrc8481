import { useEffect, useState } from 'react';
import { Menu, X, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onCartOpen: () => void;
}

const LINKS = [
  { href: '#inicio', label: 'Inicio' },
  { href: '#promos', label: 'Promos' },
  { href: '#menu', label: 'Menú' },
  { href: '#nosotros', label: 'Nosotros' },
  { href: '#contacto', label: 'Contacto' },
];

export default function Navbar({ cartCount, onCartOpen }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-marron-fondo/95 backdrop-blur-md shadow-lg shadow-black/30'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16 sm:h-20">
        <a href="#inicio" className="flex items-center gap-2 group">
          <span className="font-display text-2xl sm:text-3xl text-mostaza-clara group-hover:text-mostaza transition-colors">
            Doggy's
          </span>
        </a>

        <ul className="hidden md:flex items-center gap-8">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-crema/80 hover:text-mostaza-clara text-sm font-medium tracking-wide transition-colors relative after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-mostaza-clara after:transition-all hover:after:w-full"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <button
            onClick={onCartOpen}
            className="relative p-2 rounded-full hover:bg-crema/10 transition-colors"
            aria-label="Abrir carrito"
          >
            <ShoppingBag className="w-6 h-6 text-crema" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-rojo text-crema text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse-soft">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden p-2 rounded-lg hover:bg-crema/10 transition-colors"
            aria-label="Menú"
          >
            {open ? <X className="w-6 h-6 text-crema" /> : <Menu className="w-6 h-6 text-crema" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ${
          open ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <ul className="px-4 pb-4 space-y-1 bg-marron-fondo2/95 backdrop-blur-md">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block py-3 px-4 rounded-lg text-crema/80 hover:text-mostaza-clara hover:bg-crema/5 transition-colors font-medium"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
