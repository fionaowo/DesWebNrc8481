import { useEffect, useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, Loader2, CheckCircle2 } from 'lucide-react';
import { formatoCLP } from '@/data';
import { supabase } from '@/lib/supabase';

export interface CartItem {
  nombre: string;
  precio: number;
  cantidad: number;
}

interface CartProps {
  open: boolean;
  items: CartItem[];
  onClose: () => void;
  onInc: (nombre: string) => void;
  onDec: (nombre: string) => void;
  onRemove: (nombre: string) => void;
  onClear: () => void;
}

type Estado = 'carrito' | 'datos' | 'enviando' | 'exito' | 'error';

export default function Cart({ open, items, onClose, onInc, onDec, onRemove, onClear }: CartProps) {
  const [estado, setEstado] = useState<Estado>('carrito');
  const [nombre, setNombre] = useState('');
  const [telefono, setTelefono] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (open) setEstado('carrito');
  }, [open]);

  const total = items.reduce((s, i) => s + i.precio * i.cantidad, 0);
  const totalItems = items.reduce((s, i) => s + i.cantidad, 0);

  const confirmar = async () => {
    if (!nombre.trim() || !telefono.trim()) return;
    setEstado('enviando');
    setErrorMsg('');
    try {
      const { error } = await supabase.from('pedidos').insert({
        cliente_nombre: nombre.trim(),
        cliente_telefono: telefono.trim(),
        items: items.map((i) => ({
          nombre: i.nombre,
          precio: i.precio,
          cantidad: i.cantidad,
        })),
        total,
        estado: 'pendiente',
      });
      if (error) throw error;
      setEstado('exito');
      onClear();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'No se pudo enviar el pedido.');
      setEstado('error');
    }
  };

  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          open ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      <aside
        className={`fixed top-0 right-0 bottom-0 z-[70] w-full max-w-md bg-marron-fondo2 shadow-2xl transition-transform duration-300 flex flex-col ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-crema/10">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-mostaza-clara" />
            <h2 className="font-display text-xl text-crema">
              {estado === 'datos' ? 'Tus datos' : estado === 'exito' ? '¡Listo!' : 'Tu pedido'}
            </h2>
            {totalItems > 0 && estado === 'carrito' && (
              <span className="text-crema/40 text-sm">({totalItems})</span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-crema/10 transition-colors"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5 text-crema" />
          </button>
        </div>

        {/* Exito */}
        {estado === 'exito' && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-verde/20 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-8 h-8 text-verde" />
            </div>
            <h3 className="font-display text-2xl text-crema mb-2">¡Pedido confirmado!</h3>
            <p className="text-crema/50 text-sm mb-6">
              Lo prepararemos con cariño. Pasa a retirarlo en 10 minutos.
            </p>
            <button
              onClick={onClose}
              className="px-6 py-3 rounded-full bg-mostaza text-cafe font-semibold hover:bg-mostaza-clara transition-all"
            >
              Volver al inicio
            </button>
          </div>
        )}

        {/* Error */}
        {estado === 'error' && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-rojo/20 flex items-center justify-center mb-4">
              <X className="w-8 h-8 text-rojo-claro" />
            </div>
            <h3 className="font-display text-2xl text-crema mb-2">Algo salió mal</h3>
            <p className="text-crema/50 text-sm mb-6">{errorMsg}</p>
            <button
              onClick={() => setEstado('datos')}
              className="px-6 py-3 rounded-full bg-mostaza text-cafe font-semibold hover:bg-mostaza-clara transition-all"
            >
              Intentar de nuevo
            </button>
          </div>
        )}

        {/* Enviando */}
        {estado === 'enviando' && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <Loader2 className="w-10 h-10 text-mostaza-clara animate-spin mb-4" />
            <p className="text-crema/60 text-sm">Enviando tu pedido...</p>
          </div>
        )}

        {/* Carrito vacío */}
        {estado === 'carrito' && items.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-crema/5 flex items-center justify-center mb-4">
              <ShoppingBag className="w-8 h-8 text-crema/30" />
            </div>
            <p className="text-crema/40 text-lg">Tu carrito está vacío</p>
            <p className="text-crema/30 text-sm mt-1">Agrega algo del menú para empezar.</p>
          </div>
        )}

        {/* Carrito con items */}
        {estado === 'carrito' && items.length > 0 && (
          <>
            <div className="flex-1 overflow-y-auto p-5 space-y-3">
              {items.map((item) => (
                <div
                  key={item.nombre}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-crema-carta/5 border border-crema/10"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-crema font-medium text-sm truncate">{item.nombre}</p>
                    <p className="text-mostaza-clara text-sm font-semibold">
                      {formatoCLP(item.precio * item.cantidad)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onDec(item.nombre)}
                      className="w-8 h-8 rounded-full bg-crema/10 hover:bg-crema/20 flex items-center justify-center transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5 text-crema" />
                    </button>
                    <span className="text-crema font-medium text-sm w-6 text-center">
                      {item.cantidad}
                    </span>
                    <button
                      onClick={() => onInc(item.nombre)}
                      className="w-8 h-8 rounded-full bg-crema/10 hover:bg-crema/20 flex items-center justify-center transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5 text-crema" />
                    </button>
                    <button
                      onClick={() => onRemove(item.nombre)}
                      className="w-8 h-8 rounded-full hover:bg-rojo/20 flex items-center justify-center transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rojo-claro" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-5 border-t border-crema/10 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-crema/60 text-sm">Total</span>
                <span className="font-display text-2xl text-mostaza-clara">
                  {formatoCLP(total)}
                </span>
              </div>
              <button
                onClick={() => setEstado('datos')}
                className="w-full py-4 rounded-full bg-mostaza text-cafe font-bold hover:bg-mostaza-clara hover:scale-[1.02] transition-all"
              >
                Confirmar pedido
              </button>
            </div>
          </>
        )}

        {/* Formulario de datos */}
        {estado === 'datos' && (
          <div className="flex-1 flex flex-col p-5 overflow-y-auto">
            <div className="space-y-4 flex-1">
              <div>
                <label className="block text-crema/60 text-sm mb-1.5">Nombre</label>
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/30 focus:outline-none focus:border-mostaza/50 transition-all"
                  placeholder="Tu nombre"
                />
              </div>
              <div>
                <label className="block text-crema/60 text-sm mb-1.5">Teléfono</label>
                <input
                  type="tel"
                  value={telefono}
                  onChange={(e) => setTelefono(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/30 focus:outline-none focus:border-mostaza/50 transition-all"
                  placeholder="+56 9 1234 5678"
                />
              </div>

              {/* Resumen */}
              <div className="mt-4 p-4 rounded-2xl bg-crema-carta/5 border border-crema/10">
                <p className="text-crema/40 text-xs uppercase tracking-wider mb-3">Resumen</p>
                <div className="space-y-2">
                  {items.map((item) => (
                    <div key={item.nombre} className="flex justify-between text-sm">
                      <span className="text-crema/70">
                        {item.cantidad}x {item.nombre}
                      </span>
                      <span className="text-crema/70">
                        {formatoCLP(item.precio * item.cantidad)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-3 pt-3 border-t border-crema/10">
                  <span className="text-crema font-semibold">Total</span>
                  <span className="font-display text-lg text-mostaza-clara">
                    {formatoCLP(total)}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3 mt-4">
              <button
                onClick={confirmar}
                disabled={!nombre.trim() || !telefono.trim()}
                className="w-full py-4 rounded-full bg-mostaza text-cafe font-bold hover:bg-mostaza-clara hover:scale-[1.02] transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100"
              >
                Enviar pedido
              </button>
              <button
                onClick={() => setEstado('carrito')}
                className="w-full py-3 rounded-full text-crema/60 text-sm font-medium hover:text-crema hover:bg-crema/5 transition-all"
              >
                Volver al carrito
              </button>
            </div>
          </div>
        )}
      </aside>
    </>
  );
}
