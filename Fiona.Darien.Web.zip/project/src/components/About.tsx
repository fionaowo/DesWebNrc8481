import { Award, Leaf, Clock, Heart } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

const FEATURES = [
  {
    icon: Leaf,
    title: 'Ingredientes frescos',
    desc: 'Repostamos vegetales y carnes cada mañana. Nada congelado, nada artificial.',
  },
  {
    icon: Award,
    title: 'Receta original',
    desc: 'La misma salsa secreta desde 2012, guardada por tres generaciones.',
  },
  {
    icon: Clock,
    title: 'Rápido y caliente',
    desc: 'Tu pedido listo en menos de 10 minutos o te descontamos del total.',
  },
  {
    icon: Heart,
    title: 'Hecho con cariño',
    desc: 'Cada completo se arma a mano, uno a uno, como en casa.',
  },
];

export default function About() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="nosotros" className="py-20 sm:py-28 bg-marron-fondo relative overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute -top-20 -right-20 w-72 h-72 bg-rojo/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-mostaza/10 rounded-full blur-3xl" />

      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div className={`relative ${visible ? 'animate-fade-up' : 'opacity-0'}`}>
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-black/40">
              <img
                src="https://images.pexels.com/photos/4113458/pexels-photo-4113458.jpeg?auto=compress&cs=tinysrgb&w=900"
                alt="Completos Doggy's"
                className="w-full h-[400px] sm:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-marron-fondo/60 to-transparent" />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-2 sm:-right-6 bg-mostaza text-cafe rounded-2xl p-5 shadow-xl rotate-3 hover:rotate-0 transition-transform">
              <p className="font-display text-3xl leading-none">12</p>
              <p className="text-xs font-semibold mt-1">años sirviendo</p>
            </div>
          </div>

          {/* Content */}
          <div>
            <div className={`mb-6 ${visible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
              <span className="text-mostaza-clara text-sm font-semibold tracking-wider uppercase">
                Nuestra historia
              </span>
              <h2 className="font-display text-4xl sm:text-5xl text-crema mt-2 mb-4">
                Pasión por el<br />completo chileno
              </h2>
              <p className="text-crema/70 text-lg leading-relaxed">
                Empezamos en 2012 con un carrito en la esquina de Providencia.
                Hoy seguimos con la misma receta, el mismo cariño y la misma
                promesa: completos abundantes, sabrosos y honestos.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-5">
              {FEATURES.map((f, i) => (
                <div
                  key={f.title}
                  className={`flex gap-3 ${visible ? 'animate-fade-up' : 'opacity-0'}`}
                  style={{ animationDelay: `${0.2 + i * 0.1}s` }}
                >
                  <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-mostaza/15 flex items-center justify-center">
                    <f.icon className="w-5 h-5 text-mostaza-clara" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-crema text-base mb-1">{f.title}</h3>
                    <p className="text-crema/50 text-sm leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
