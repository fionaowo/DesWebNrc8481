import { useState } from 'react';
import { Flame, Plus } from 'lucide-react';
import { PROMOS, CATEGORIAS, formatoCLP, type Categoria } from '@/data';
import { useReveal } from '@/hooks/useReveal';

interface PromosProps {
  onAdd: (nombre: string, precio: number) => void;
}

export default function Promos({ onAdd }: PromosProps) {
  const [active, setActive] = useState<Categoria>('italianos');
  const { ref, visible } = useReveal<HTMLDivElement>();
  const items = PROMOS[active];

  return (
    <section id="promos" className="py-20 sm:py-28 bg-marron-fondo3 relative">
      {/* Decorative wave top */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-mostaza/30 to-transparent" />

      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className={`mb-12 ${visible ? 'animate-fade-up' : 'opacity-0'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-rojo/20 border border-rojo/40 mb-4">
            <Flame className="w-4 h-4 text-rojo-claro" />
            <span className="text-rojo-claro text-sm font-medium">Ofertas de la semana</span>
          </div>
          <h2 className="font-display text-4xl sm:text-5xl text-crema mb-3">
            Promos que <span className="text-mostaza-clara">enloquecen</span>
          </h2>
          <p className="text-crema/60 text-lg max-w-xl">
            Combos pensados para cada antojo. Precios de verdad, sin trucos.
          </p>
        </div>

        {/* Category tabs */}
        <div className="flex gap-2 mb-10 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIAS.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActive(cat.id)}
              className={`px-6 py-2.5 rounded-full font-medium text-sm whitespace-nowrap transition-all ${
                active === cat.id
                  ? 'bg-mostaza text-cafe shadow-lg shadow-mostaza/30'
                  : 'bg-crema/5 text-crema/60 hover:bg-crema/10 hover:text-crema border border-crema/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, i) => (
            <article
              key={item.nombre}
              className={`group bg-crema-carta rounded-3xl overflow-hidden shadow-xl shadow-black/20 transition-all hover:shadow-2xl hover:-translate-y-1 ${
                visible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="relative h-52 overflow-hidden">
                <img
                  src={item.img}
                  alt={item.nombre}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                {item.antes && (
                  <span className="absolute top-4 right-4 bg-rojo text-crema text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">
                    -{Math.round((1 - item.precio / item.antes) * 100)}%
                  </span>
                )}
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl text-cafe mb-2">{item.nombre}</h3>
                <p className="text-tinta/70 text-sm mb-4 leading-relaxed">{item.desc}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-2xl text-rojo">
                      {formatoCLP(item.precio)}
                    </span>
                    {item.antes && (
                      <span className="text-tinta/40 text-sm line-through">
                        {formatoCLP(item.antes)}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => onAdd(item.nombre, item.precio)}
                    className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-cafe text-crema text-sm font-semibold hover:bg-rojo transition-all hover:scale-105 active:scale-95"
                  >
                    <Plus className="w-4 h-4" />
                    Agregar
                  </button>
                </div>
              </div>
            </article>
          ))}

          {/* Fill card for grid balance when 2 items */}
          <div className="hidden lg:flex flex-col items-center justify-center p-8 rounded-3xl border-2 border-dashed border-crema/15 text-center">
            <p className="font-display text-2xl text-mostaza-clara mb-2">¿Más hambre?</p>
            <p className="text-crema/50 text-sm">
              Arma tu combo con los ingredientes que quieras en el menú completo.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
