import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

export default function Contact() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contacto" className="py-20 sm:py-28 bg-marron-fondo">
      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className={`mb-12 ${visible ? 'animate-fade-up' : 'opacity-0'}`}>
          <h2 className="font-display text-4xl sm:text-5xl text-crema mb-3">
            Pide o <span className="text-mostaza-clara">visítanos</span>
          </h2>
          <p className="text-crema/60 text-lg max-w-xl">
            Hacemos delivery, retiro en local y catering para eventos.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Contact info */}
          <div className={`space-y-4 ${visible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
            {[
              { icon: MapPin, label: 'Dirección', value: 'Av. Providencia 1234, Local 5, Santiago' },
              { icon: Phone, label: 'Teléfono', value: '+56 9 1234 5678' },
              { icon: Mail, label: 'Email', value: 'hola@doggys.cl' },
              { icon: Clock, label: 'Horario', value: 'Lun a Dom · 11:00 — 23:30' },
            ].map((c) => (
              <div
                key={c.label}
                className="flex items-start gap-4 p-5 rounded-2xl bg-crema-carta/5 border border-crema/10 hover:border-mostaza/30 transition-colors"
              >
                <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-mostaza/15 flex items-center justify-center">
                  <c.icon className="w-5 h-5 text-mostaza-clara" />
                </div>
                <div>
                  <p className="text-crema/40 text-xs uppercase tracking-wider mb-1">{c.label}</p>
                  <p className="text-crema font-medium">{c.value}</p>
                </div>
              </div>
            ))}

            {/* Map placeholder */}
            <div className="rounded-2xl overflow-hidden h-48 border border-crema/10 bg-crema-carta/5 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-10 h-10 text-mostaza/40 mx-auto mb-2" />
                <p className="text-crema/40 text-sm">Providencia, Santiago</p>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className={`p-7 sm:p-8 rounded-3xl bg-crema-carta/5 border border-crema/10 ${visible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            <h3 className="font-display text-2xl text-crema mb-6">Envíanos un mensaje</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-crema/60 text-sm mb-1.5">Nombre</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/30 focus:outline-none focus:border-mostaza/50 transition-all"
                  placeholder="Tu nombre"
                />
              </div>
              <div>
                <label className="block text-crema/60 text-sm mb-1.5">Email</label>
                <input
                  type="email"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/30 focus:outline-none focus:border-mostaza/50 transition-all"
                  placeholder="tucorreo@email.cl"
                />
              </div>
              <div>
                <label className="block text-crema/60 text-sm mb-1.5">Mensaje</label>
                <textarea
                  required
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/30 focus:outline-none focus:border-mostaza/50 transition-all resize-none"
                  placeholder="Cuéntanos qué necesitas..."
                />
              </div>
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-mostaza text-cafe font-bold hover:bg-mostaza-clara hover:scale-[1.02] transition-all"
              >
                <Send className="w-4 h-4" />
                {sent ? '¡Mensaje enviado!' : 'Enviar mensaje'}
              </button>
              {sent && (
                <p className="text-verde text-sm text-center animate-fade-in">
                  Gracias por escribirnos. Te responderemos pronto.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
