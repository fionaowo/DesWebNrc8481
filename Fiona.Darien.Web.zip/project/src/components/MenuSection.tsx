import { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import { MENU, formatoCLP, type MenuItem } from '@/data';
import { useReveal } from '@/hooks/useReveal';

interface MenuSectionProps {
  onAdd: (nombre: string, precio: number) => void;
}

const FILTROS = [
  { id: 'todos', label: 'Todos' },
  { id: 'completo', label: 'Completos' },
  { id: 'americano', label: 'Americanos' },
];

export default function MenuSection({ onAdd }: MenuSectionProps) {
  const [filtro, setFiltro] = useState('todos');
  const [query, setQuery] = useState('');
  const { ref, visible } = useReveal<HTMLDivElement>();

  const filtrados: MenuItem[] = MENU.filter((m) => {
    const matchFiltro = filtro === 'todos' || m.tipo === filtro;
    const matchQuery = m.nombre.toLowerCase().includes(query.toLowerCase());
    return matchFiltro && matchQuery;
  });

  return (
    <section id="menu" className="py-20 sm:py-28 bg-marron-fondo2">
      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className={`mb-10 ${visible ? 'animate-fade-up' : 'opacity-0'}`}>
          <h2 className="font-display text-4xl sm:text-5xl text-crema mb-3">
            Nuestro <span className="text-mostaza-clara">menú</span>
          </h2>
          <p className="text-crema/60 text-lg max-w-xl">
            Cada completo se prepara al momento. Elige tu favorito.
          </p>
        </div>

        {/* Controls */}
        <div className={`flex flex-col sm:flex-row gap-4 mb-8 ${visible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
          <div className="flex gap-2">
            {FILTROS.map((f) => (
              <button
                key={f.id}
                onClick={() => setFiltro(f.id)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                  filtro === f.id
                    ? 'bg-mostaza text-cafe'
                    : 'bg-crema/5 text-crema/60 hover:bg-crema/10 border border-crema/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-crema/40" />
            <input
              type="text"
              placeholder="Buscar en el menú..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-crema/5 border border-crema/10 text-crema placeholder:text-crema/40 text-sm focus:outline-none focus:border-mostaza/50 focus:bg-crema/10 transition-all"
            />
          </div>
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtrados.map((item, i) => (
            <article
              key={item.nombre}
              className={`group flex gap-4 p-4 rounded-2xl bg-crema-carta/5 border border-crema/10 hover:border-mostaza/30 hover:bg-crema-carta/10 transition-all ${visible ? 'animate-fade-up' : 'opacity-0'}`}
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                <img
                  src={item.img}
                  alt={item.nombre}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-crema text-base mb-0.5 truncate">{item.nombre}</h3>
                <p className="text-crema/40 text-xs capitalize mb-2">{item.tipo}</p>
                <div className="flex items-center justify-between">
                  <span className="font-display text-lg text-mostaza-clara">
                    {formatoCLP(item.precio)}
                  </span>
                  <button
                    onClick={() => onAdd(item.nombre, item.precio)}
                    className="p-2 rounded-full bg-mostaza/15 text-mostaza-clara hover:bg-mostaza hover:text-cafe transition-all hover:scale-110 active:scale-90"
                    aria-label={`Agregar ${item.nombre}`}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        {filtrados.length === 0 && (
          <div className="text-center py-16">
            <p className="text-crema/40 text-lg">No encontramos resultados para tu búsqueda.</p>
          </div>
        )}
      </div>
    </section>
  );
}
