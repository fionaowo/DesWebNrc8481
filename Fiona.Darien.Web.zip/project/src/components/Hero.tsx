import { ChevronDown, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/4113472/pexels-photo-4113472.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Hot dogs Doggy's"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-marron-fondo via-marron-fondo/90 to-marron-fondo/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-marron-fondo via-transparent to-marron-fondo/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 w-full pt-20">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-mostaza/15 border border-mostaza/30 mb-6 animate-fade-in">
            <Star className="w-4 h-4 fill-mostaza-clara text-mostaza-clara" />
            <span className="text-mostaza-clara text-sm font-medium">
              #1 en completos de la ciudad
            </span>
          </div>

          <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl text-crema leading-[1.05] mb-6 animate-fade-up">
            Completos<br />
            <span className="text-mostaza-clara">100%</span> naturales
          </h1>

          <p className="text-crema/80 text-lg sm:text-xl mb-8 max-w-lg leading-relaxed animate-fade-up" style={{ animationDelay: '0.1s', opacity: 0 }}>
            Ingredientes frescos cada día, pan amasado en casa y esa salsa
            secreta que te hace volver. Así de simple, así de rico.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 animate-fade-up" style={{ animationDelay: '0.2s', opacity: 0 }}>
            <a
              href="#promos"
              className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-mostaza text-cafe font-bold text-base hover:bg-mostaza-clara hover:scale-105 transition-all shadow-lg shadow-mostaza/30"
            >
              Ver promociones
            </a>
            <a
              href="#menu"
              className="inline-flex items-center justify-center px-8 py-4 rounded-full border-2 border-crema/30 text-crema font-semibold text-base hover:bg-crema/10 hover:border-crema/50 transition-all"
            >
              Explorar el menú
            </a>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-8 mt-12 pt-8 border-t border-crema/10 animate-fade-up" style={{ animationDelay: '0.3s', opacity: 0 }}>
            <div>
              <p className="font-display text-3xl text-mostaza-clara">+15K</p>
              <p className="text-crema/60 text-sm">Clientes felices</p>
            </div>
            <div>
              <p className="font-display text-3xl text-mostaza-clara">4.9</p>
              <p className="text-crema/60 text-sm">Calificación promedio</p>
            </div>
            <div className="hidden sm:block">
              <p className="font-display text-3xl text-mostaza-clara">12</p>
              <p className="text-crema/60 text-sm">Años de historia</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#promos"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 text-crema/50 hover:text-mostaza-clara transition-colors animate-float"
        aria-label="Desplazarse"
      >
        <ChevronDown className="w-8 h-8" />
      </a>
    </section>
  );
}
