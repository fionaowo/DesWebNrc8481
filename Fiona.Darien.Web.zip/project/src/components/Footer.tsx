import { Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-marron-fondo2 pt-16 pb-8 border-t border-crema/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="lg:col-span-2">
            <h3 className="font-display text-3xl text-mostaza-clara mb-3">Doggy's</h3>
            <p className="text-crema/50 text-sm max-w-xs leading-relaxed">
              Completos y hot dogs al estilo chileno. Hechos con ingredientes
              frescos y mucho cariño desde 2012.
            </p>
            <div className="flex gap-3 mt-5">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full bg-crema/5 border border-crema/10 flex items-center justify-center text-crema/60 hover:bg-mostaza hover:text-cafe hover:border-mostaza transition-all"
                  aria-label="Red social"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-crema font-semibold mb-4 text-sm uppercase tracking-wider">Menú</h4>
            <ul className="space-y-2 text-crema/50 text-sm">
              <li><a href="#promos" className="hover:text-mostaza-clara transition-colors">Promociones</a></li>
              <li><a href="#menu" className="hover:text-mostaza-clara transition-colors">Completos</a></li>
              <li><a href="#menu" className="hover:text-mostaza-clara transition-colors">Hot Dogs</a></li>
              <li><a href="#menu" className="hover:text-mostaza-clara transition-colors">Combos</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-crema font-semibold mb-4 text-sm uppercase tracking-wider">Nosotros</h4>
            <ul className="space-y-2 text-crema/50 text-sm">
              <li><a href="#nosotros" className="hover:text-mostaza-clara transition-colors">Historia</a></li>
              <li><a href="#contacto" className="hover:text-mostaza-clara transition-colors">Contacto</a></li>
              <li><a href="#contacto" className="hover:text-mostaza-clara transition-colors">Delivery</a></li>
              <li><a href="#contacto" className="hover:text-mostaza-clara transition-colors">Catering</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-crema/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-crema/30 text-sm">
            © 2024 Doggy's. Todos los derechos reservados.
          </p>
          <div className="flex gap-6 text-crema/30 text-sm">
            <a href="#" className="hover:text-mostaza-clara transition-colors">Términos</a>
            <a href="#" className="hover:text-mostaza-clara transition-colors">Privacidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
