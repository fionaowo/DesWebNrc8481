import { useState, useCallback } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Promos from '@/components/Promos';
import MenuSection from '@/components/MenuSection';
import About from '@/components/About';
import Testimonials from '@/components/Testimonials';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import Cart, { type CartItem } from '@/components/Cart';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  const addToCart = useCallback((nombre: string, precio: number) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.nombre === nombre);
      if (existing) {
        return prev.map((i) =>
          i.nombre === nombre ? { ...i, cantidad: i.cantidad + 1 } : i,
        );
      }
      return [...prev, { nombre, precio, cantidad: 1 }];
    });
    setCartOpen(true);
  }, []);

  const incItem = useCallback((nombre: string) => {
    setCart((prev) =>
      prev.map((i) => (i.nombre === nombre ? { ...i, cantidad: i.cantidad + 1 } : i)),
    );
  }, []);

  const decItem = useCallback((nombre: string) => {
    setCart((prev) =>
      prev
        .map((i) => (i.nombre === nombre ? { ...i, cantidad: i.cantidad - 1 } : i))
        .filter((i) => i.cantidad > 0),
    );
  }, []);

  const removeItem = useCallback((nombre: string) => {
    setCart((prev) => prev.filter((i) => i.nombre !== nombre));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const cartCount = cart.reduce((s, i) => s + i.cantidad, 0);

  return (
    <div className="min-h-screen">
      <Navbar cartCount={cartCount} onCartOpen={() => setCartOpen(true)} />
      <main>
        <Hero />
        <Promos onAdd={addToCart} />
        <MenuSection onAdd={addToCart} />
        <About />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
      <Cart
        open={cartOpen}
        items={cart}
        onClose={() => setCartOpen(false)}
        onInc={incItem}
        onDec={decItem}
        onRemove={removeItem}
        onClear={clearCart}
      />
    </div>
  );
}
