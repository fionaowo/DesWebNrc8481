# Doggy's - API REST con separacion publico/privado

Caso 28: Hot dogs "Doggy's" - completos y hot dogs americanos.

## Arquitectura

- **api-privada/** (puerto 4001): API REST con el CRUD del menu de hot dogs. No se expone directo al cliente.
- **api-gateway/** (puerto 3000): unico punto de entrada publico. Valida un secreto (header `x-api-key`) y reenvia la peticion a la api-privada.
- **administrador de secretos**: archivo `.env` con `API_SECRET`, leido por el gateway para validar el acceso.

## Como probarlo

1. `cd api-privada && npm install && npm start`
2. `cd api-gateway && npm install`, crea tu `.env` copiando `.env.example`, y `npm start`
3. Prueba:
   - Sin `x-api-key` -> 401
   - Con `x-api-key: doggys2026` -> lista los hot dogs

Ejemplo:
```
curl.exe http://localhost:3000/hotdogs -H "x-api-key: doggys2026"
```
