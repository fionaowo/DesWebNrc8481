const express = require('express');
const app = express();
app.use(express.json());

let hotdogs = [
    { id: 1, nombre: "Completo Italiano", tipo: "completo", precio: 2500 },
    { id: 2, nombre: "Completo Dinamico", tipo: "completo", precio: 2300 },
    { id: 3, nombre: "Hot Dog Americano", tipo: "americano", precio: 2800 }
];
let siguienteId = 4;

app.get('/hotdogs', (req, res) => {
    res.json(hotdogs);
});

app.get('/hotdogs/:id', (req, res) => {
    const hotdog = hotdogs.find(h => h.id == req.params.id);
    if (!hotdog) {
        return res.status(404).json({ message: "Hot dog no encontrado" });
    }
    res.json(hotdog);
});

app.post('/hotdogs', (req, res) => {
    const nuevo = { id: siguienteId++, nombre: req.body.nombre, tipo: req.body.tipo, precio: req.body.precio };
    hotdogs.push(nuevo);
    res.status(201).json(nuevo);
});

app.put('/hotdogs/:id', (req, res) => {
    const hotdog = hotdogs.find(h => h.id == req.params.id);
    if (!hotdog) {
        return res.status(404).json({ message: "Hot dog no encontrado" });
    }
    hotdog.nombre = req.body.nombre;
    hotdog.tipo = req.body.tipo;
    hotdog.precio = req.body.precio;
    res.json(hotdog);
});

app.delete('/hotdogs/:id', (req, res) => {
    const index = hotdogs.findIndex(h => h.id == req.params.id);
    if (index == -1) {
        return res.status(404).json({ message: "Hot dog no encontrado" });
    }
    hotdogs.splice(index, 1);
    res.json({ message: "Hot dog eliminado" });
});

app.listen(4001, () => {
    console.log("API privada de Doggy's corriendo en http://localhost:4001");
});
